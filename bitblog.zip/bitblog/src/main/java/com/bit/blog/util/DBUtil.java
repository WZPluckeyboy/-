package com.bit.blog.util;

import com.bit.blog.constant.Message;
import com.bit.blog.exception.SystemException;
import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.stream.Collectors;

public class DBUtil {

	private static final String URL      = "jdbc:mysql://127.0.0.1:3306/bitblog?characterEncoding=utf8&useSSL=true"; // 数据库地址
	private static final String USERNAME = "root";
	private static final String PASSWORD = "root";


	private static volatile DataSource ds = null;

	public static DataSource getDataSource() {
		if (ds == null) {
			synchronized (DBUtil.class) {
				if (ds == null) {
					ds = new MysqlDataSource();
					((MysqlDataSource) ds).setUrl(URL);
					((MysqlDataSource) ds).setUser(USERNAME);
					((MysqlDataSource) ds).setPassword(PASSWORD);
				}
			}
		}
		return ds;
	}

	public static Connection getConnection() {
		try {
			return getDataSource().getConnection();
		} catch (Exception e) {
			throw new SystemException(Message.S002_CODE, Message.S002_MESSAGE);
		}
	}

	public static void close(Connection conn, PreparedStatement ps,
							 ResultSet rs){
		try {
			if(rs != null){
				rs.close();
			}
			if(ps != null){
				ps.close();
			}
			if(conn != null){
				conn.close();
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static void close(Connection conn, PreparedStatement ps){
		close(conn, ps, null);
	}
}
