package com.bit.blog.util;

import com.bit.blog.constant.Message;
import com.bit.blog.exception.ParameterException;
import com.bit.blog.exception.SystemException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;

public class JSONUtil {
	
	public static <T> T read(String json, Class<T> clazz) throws IOException {
		return JSONMapper.getInstance().readValue(json, clazz);
	}
	
	/**
	 * <p>
	 * 读取Http请求JSON数据，请求类型必须是application/json
	 * <p>
	 * @param request
	 * @param clazz
	 * @return
	 * @throws IOException
	 */
	public static <T> T readRequestJSON(HttpServletRequest request, Class<T> clazz) {
		try {
			return JSONMapper.getInstance().readValue(request.getInputStream(), clazz);
		} catch (IOException e) {
			throw new ParameterException(
					Message.P001_CODE,
					Message.P001_MESSAGE);
		}
	}
	
	public static <T> void writeResponseJSON(HttpServletResponse response, T obj) {
		try {
			JSONMapper.getInstance().writeValue(response.getOutputStream(), obj);
		} catch (IOException e) {
			throw new SystemException(
					Message.S001_CODE,
					Message.S001_MESSAGE);
		}
	}
	
	private static class JSONMapper extends ObjectMapper
	{
	    private static final long serialVersionUID = 7679503945581779104L;
	    
	    private static final String DEFAULT_DATE_PATTERN = "yyyy-MM-dd HH:mm:ss";
	    
	    private JSONMapper(){
	    	
	    }
		
		public static ObjectMapper getInstance(){
			ObjectMapper mapper = new ObjectMapper();
			mapper.setDateFormat(new SimpleDateFormat(DEFAULT_DATE_PATTERN));
			// 允许单引号
			mapper.enable(JsonParser.Feature.ALLOW_SINGLE_QUOTES);
			// 字段和值都加引号
//			mapper.enable(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES);
			// 数字也加引号
//			mapper.enable(JsonGenerator.Feature.WRITE_NUMBERS_AS_STRINGS);
//			mapper.enable(JsonGenerator.Feature.QUOTE_NON_NUMERIC_NUMBERS);
			
			// 美化打印输出
			mapper.enable(SerializationFeature.INDENT_OUTPUT);

			return mapper;
		}
	}
}
