package com.bit.blog.servlet;

import com.bit.blog.constant.Message;
import com.bit.blog.exception.ParameterException;
import com.bit.blog.model.Article;
import com.bit.blog.util.DBUtil;
import com.bit.blog.util.JSONUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
 
public class ArticleUpdateServlet extends AbstractBaseServlet {
	
	private static final long serialVersionUID = 1L;
 
	@Override
	protected Object process(HttpServletRequest req, HttpServletResponse resp) throws Throwable {
		Article article = JSONUtil.readRequestJSON(req, Article.class);
		if(!update(article)){
			throw new ParameterException(
					Message.P003_CODE,
					String.format(Message.P003_MESSAGE,
							article.getId()));
		}
		return null;
	}
	
	public static boolean update(Article article) throws SQLException {
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		String sql = "update t_article set title=?,content=? where id=?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, article.getTitle());
			ps.setString(2, article.getContent());
			ps.setInt(3, article.getId());
			System.out.println(ps.toString());
			int i = ps.executeUpdate();
			return i > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally{
			DBUtil.close(conn, ps);
		}
	}

	
}