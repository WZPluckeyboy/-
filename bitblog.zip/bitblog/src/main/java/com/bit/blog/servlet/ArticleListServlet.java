package com.bit.blog.servlet;

import com.bit.blog.model.Article;
import com.bit.blog.util.DBUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * 查询文章列表（默认查询账号stu）
 * @author Frank
 *
 */
public class ArticleListServlet extends AbstractBaseServlet {
	
	private static final long serialVersionUID = 1L;
 
	@Override
	protected Object process(HttpServletRequest req, HttpServletResponse resp) throws Throwable {
		String accout = req.getParameter("userAccout");
		return list(accout);
	}
	
	public static List<Article> list(String accout) throws SQLException {
		List<Article> list = new ArrayList<>();
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select article.id, article.title from t_article article"
				+ " join t_user user on article.user_id = user.id where user.user_accout = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, accout);
			rs = ps.executeQuery();
			while (rs.next()) {
				Article article = new Article();
				article.setId(rs.getInt("id"));
				article.setTitle(rs.getString("title"));
				list.add(article);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally{
			DBUtil.close(conn, ps, rs);
		}
		return list;
	}

}
