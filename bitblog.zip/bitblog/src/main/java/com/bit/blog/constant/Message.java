package com.bit.blog.constant;

public class Message {

	public static final String OK_CODE          = "200";
	public static final String OK_MESSAGE       = "操作成功";
	public static final String P_CODE_PREFIX    = "p_";
	public static final String P_MESSAGE_PREFIX = "请求参数错误：";
	public static final String S_CODE_PREFIX    = "s_";
	public static final String S_MESSAGE_PREFIX = "";
	public static final String UNKNOWN_CODE     = "unknown";
	public static final String UNKNOWN_MESSAGE  = "服务器未知异常";
	
	public static final String P001_CODE    = "001";
	public static final String P001_MESSAGE = "请求JSON数据格式错误";
	public static final String P002_CODE    = "002";
	public static final String P002_MESSAGE = "新增文章失败，用户%s不存在";
	public static final String P003_CODE    = "003";
	public static final String P003_MESSAGE = "修改文章失败，文章%s不存在";
	public static final String P004_CODE    = "004";
	public static final String P004_MESSAGE = "删除文章失败，文章%s不存在";
	
	public static final String S001_CODE    = "001";
	public static final String S001_MESSAGE = "服务器JSON转换错误";

	public static final String S002_CODE    = "002";
	public static final String S002_MESSAGE = "数据库连接错误";

}
