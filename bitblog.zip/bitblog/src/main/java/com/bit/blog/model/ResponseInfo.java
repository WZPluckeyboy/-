package com.bit.blog.model;

import com.bit.blog.constant.Message;
import com.bit.blog.exception.BaseException;

import java.io.Serializable;

public class ResponseInfo implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private boolean success;

	private String code;
	
	private String message;
	
	private String stackTrace;
	
	private Object data;

	public ResponseInfo() {
		this.success = true;
		this.code = Message.OK_CODE;
		this.message = Message.OK_MESSAGE;
	}

	public ResponseInfo(String code, String message) {
		this.code = code;
		this.message = message;
	}

	public ResponseInfo(Throwable t) {
		if(t instanceof BaseException){
			BaseException be = (BaseException) t;
			this.code = be.getCode();
			this.message = be.getMessage();
		}else{
			this.code = Message.UNKNOWN_CODE;
			this.message = Message.UNKNOWN_MESSAGE;
		}
	}

	public boolean isSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStackTrace() {
		return stackTrace;
	}

	public void setStackTrace(String stackTrace) {
		this.stackTrace = stackTrace;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

}
