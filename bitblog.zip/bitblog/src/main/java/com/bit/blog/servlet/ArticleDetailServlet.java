package com.bit.blog.servlet;

import com.bit.blog.model.Article;
import com.bit.blog.util.DBUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * 查询文章列表（默认查询账号stu）
 * @author Frank
 *
 */
public class ArticleDetailServlet extends AbstractBaseServlet {
	
	private static final long serialVersionUID = 1L;
 
	@Override
	protected Object process(HttpServletRequest req, HttpServletResponse resp) throws Throwable {
		int articleId = Integer.parseInt(req.getParameter("id"));
		return select(articleId);
	}
	
	public static Article select(int articleId) throws SQLException {
		Article article = new Article();
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		ResultSet rs = null;
		String sql = "select id, title, content from t_article where id = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setInt(1, articleId);
			rs = ps.executeQuery();
			while (rs.next()) {
				article.setId(rs.getInt("id"));
				article.setTitle(rs.getString("title"));
				article.setContent(rs.getString("content"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally{
			DBUtil.close(conn, ps, rs);
		}
		return article;
	}

}
