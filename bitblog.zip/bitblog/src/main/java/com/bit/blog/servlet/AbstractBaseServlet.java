package com.bit.blog.servlet;

import com.bit.blog.model.ResponseInfo;
import com.bit.blog.util.JSONUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

public abstract class AbstractBaseServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private static final String CHARSET = "UTF-8";

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		// GET方式获取请求参数时，参数中包含中文时，需要设置编码
//		String param = URLEncoder.encode(req.getParameter("param"), "UTF-8");
		
		req.setCharacterEncoding(CHARSET);
		
		resp.setContentType("application/json;charset=utf-8");
//		resp.setHeader("Content-type", "application/json;charset=utf-8");
		
		ResponseInfo json = null;
		try {
			Object data = process(req, resp);
			if(data instanceof ResponseInfo){
				json = (ResponseInfo) data;
			}else{
				json = new ResponseInfo();
				json.setData(data);
			}
			
		} catch (Throwable t) {
			json = new ResponseInfo(t);
			if("dev001".equals(req.getParameter("devToken"))){
				StringWriter sw = new StringWriter();
				PrintWriter pw = new PrintWriter(sw, true);
		        t.printStackTrace(pw);
				json.setStackTrace(sw.getBuffer().toString());
			}else{
				t.printStackTrace();
			}
		}
		JSONUtil.writeResponseJSON(resp, json);
	}
	
	protected abstract Object process(HttpServletRequest req, HttpServletResponse resp) throws Throwable;

}
