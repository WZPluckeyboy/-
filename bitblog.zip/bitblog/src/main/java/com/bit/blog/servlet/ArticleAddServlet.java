package com.bit.blog.servlet;

import com.bit.blog.constant.Message;
import com.bit.blog.exception.ParameterException;
import com.bit.blog.model.Article;
import com.bit.blog.util.DBUtil;
import com.bit.blog.util.JSONUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
 
public class ArticleAddServlet extends AbstractBaseServlet {
	private static final long serialVersionUID = 1L;
 
	@Override
	protected Object process(HttpServletRequest req, HttpServletResponse resp) throws Throwable {
		Article article = JSONUtil.readRequestJSON(req, Article.class);
		if(!insert(article)){
			throw new ParameterException(
					Message.P002_CODE,
					String.format(Message.P002_MESSAGE,
							article.getUserAccout()));
		}
		return null;
	}
	
	public static boolean insert(Article article) throws SQLException {
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		String sql = "insert into t_article(title, content, create_time, user_id)"
				+ " select ?, ?, now(), t_user.id from t_user where t_user.user_accout = ?";
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, article.getTitle());
			ps.setString(2, article.getContent());
			ps.setString(3, article.getUserAccout());

			System.out.println(ps.toString());
			int i = ps.executeUpdate();
			return i > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally{
            DBUtil.close(conn, ps);
		}
	}

}