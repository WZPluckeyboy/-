package com.bit.blog.exception;

import com.bit.blog.constant.Message;

public class ParameterException extends BaseException {

	private static final long serialVersionUID = 1L;

	public ParameterException(String code, String message, Throwable arg1) {
		super(Message.P_CODE_PREFIX +code, Message.P_MESSAGE_PREFIX +message, arg1);
	}

	public ParameterException(String code, String message) {
		super(Message.P_CODE_PREFIX +code, Message.P_MESSAGE_PREFIX +message);
	}
	
}
