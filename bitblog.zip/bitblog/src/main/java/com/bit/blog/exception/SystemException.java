package com.bit.blog.exception;

import com.bit.blog.constant.Message;

public class SystemException extends BaseException {

	private static final long serialVersionUID = 1L;

	public SystemException(String code, String message, Throwable arg1) {
		super(Message.S_CODE_PREFIX +code, Message.S_MESSAGE_PREFIX +message, arg1);
	}

	public SystemException(String code, String message) {
		super(Message.S_CODE_PREFIX +code, Message.S_MESSAGE_PREFIX +message);
	}

}
