package com.bit.blog.servlet;

import com.bit.blog.constant.Message;
import com.bit.blog.exception.ParameterException;
import com.bit.blog.util.DBUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.stream.Collectors;

public class ArticleDeleteServlet extends AbstractBaseServlet {
	
	private static final long serialVersionUID = 1L;

	@Override
	protected Object process(HttpServletRequest req, HttpServletResponse resp) throws Throwable {
		int[] ids = Arrays.stream(req.getParameter("ids").split(","))
				.mapToInt(Integer::valueOf).toArray();
		if(!delete(ids)){
			throw new ParameterException(
					Message.P004_CODE,
					String.format(Message.P004_MESSAGE,
							req.getParameter("ids")));
		}
		return null;
	}

	public static boolean delete(int[] ids) throws SQLException {
		Connection conn = DBUtil.getConnection();
		PreparedStatement ps = null;
		StringBuilder sql = new StringBuilder("delete from t_article where id in (");
		try {
			
			// for Oracle/SQL Server
//			Array array = conn.createArrayOf("VARCHAR", new Object[]{"1", "2","3"}); 
//			ps.setArray(1, array);
			if(ids == null || ids.length == 0) {
				return false;
			}
			for(int i=0; i<ids.length; i++) {
				if(i==0) {
					sql.append("?");
				}else {
					sql.append(", ?");
				}
			}
			sql.append(")");
			ps = conn.prepareStatement(sql.toString());
			for(int i=0; i<ids.length; i++) {
				ps.setInt(i+1, ids[i]);
			}
			System.out.println(ps.toString());
			int i = ps.executeUpdate();
			return i > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally{
			DBUtil.close(conn, ps);
		}
	}
}